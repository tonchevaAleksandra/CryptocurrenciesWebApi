import { ChangedPipe } from './changed.pipe';

describe('ChangedPipe', () => {
  it('create an instance', () => {
    const pipe = new ChangedPipe();
    expect(pipe).toBeTruthy();
  });
});
